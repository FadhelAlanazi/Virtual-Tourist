//
//  PhotosCollectionCells.swift
//  Virtual Tourist
//
//  Created by Fadhel Alanazi on 04/04/1441 AH.
//  Copyright © 1441 udacity.com. All rights reserved.
//

import UIKit

class PhotosCollectionCells: UICollectionViewCell
{
    var imageUrl: String = ""
    @IBOutlet weak var imageCell: UIImageView!
    @IBOutlet weak var activity: UIActivityIndicatorView!
    
}
