//
//  PinCoreData.swift
//  Virtual Tourist
//
//  Created by Fadhel Alanazi on 02/04/1441 AH.
//  Copyright © 1441 udacity.com. All rights reserved.
//

import Foundation
import CoreData

@objc(Pin)
public class Pin: NSManagedObject
{
    
    static let name = "Pin"
    convenience init(latitude: String, longitude: String , context: NSManagedObjectContext)
    {
        if let entity = NSEntityDescription.entity(forEntityName: Pin.name, in: context)
        {
            self.init(entity: entity, insertInto: context)
            self.latitude = latitude
            self.longitude = longitude
        }
        else
        {
            fatalError("No entity with name Pin")
        }
    }
}

extension Pin
{
    @nonobjc public class func fetchRequest() -> NSFetchRequest<Pin>
    {
        return NSFetchRequest<Pin>(entityName: "Pin")
    }
    
    @NSManaged public var latitude: String?
    @NSManaged public var longitude: String?
    @NSManaged public var photos: NSSet?
    
    
    @objc(addPhotosObjet:)
    @NSManaged public func addToPhotos(_ value: Photo)
    
    @objc(removePhotosObject:)
    @NSManaged public func removeFromPhotos(_ value: Photo)
    
    @objc(addPhotos:)
    @NSManaged public func addToPhotos(_ values: NSSet)
    
    @objc(removePhotos:)
    @NSManaged public func removeFromPhotos(_ values: NSSet)
}


