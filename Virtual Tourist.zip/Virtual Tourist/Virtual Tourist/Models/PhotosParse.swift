//
//  PhotosParse.swift
//  Virtual Tourist
//
//  Created by Fadhel Alanazi on 03/04/1441 AH.
//  Copyright © 1441 udacity.com. All rights reserved.
//

import Foundation

struct PhotosParse: Codable
{
    let photos: Photos
}

struct Photos: Codable
{
    let pages: Int
    let photo: [PhotoParse]
}

struct PhotoParse: Codable
{
    let url: String?
    let title: String
    
    enum CodeingKeys: String, CodingKey
    {
        case url = "url_n"
        case title
    }
}
