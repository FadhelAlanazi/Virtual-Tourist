//
//  CoreDataStack.swift
//  Virtual Tourist
//
//  Created by Fadhel Alanazi on 02/04/1441 AH.
//  Copyright © 1441 udacity.com. All rights reserved.
//

import Foundation
import CoreData

struct Core_Data
{
    private let model: NSManagedObjectModel
    internal let coordinator: NSPersistentStoreCoordinator
    private let modelURL: URL
    internal let dbURL: URL
    internal let persistingContext: NSManagedObjectContext
    internal let backgroundContext: NSManagedObjectContext
    let context: NSManagedObjectContext
    
   static func shared() -> Core_Data
   {
      struct Singleton
      {
         static var shared = Core_Data(modelName: "Virtual_Tourist")!
      }
    return Singleton.shared
   }
    
    init?(modelName: String)
    {
        guard let modelURL = Bundle.main.url(forResource: modelName, withExtension: "momd")
        else
        {
            print("unable to find \(modelName) in the main bundle")
            return nil
        }
        
        self.modelURL = modelURL
        
        guard let model = NSManagedObjectModel(contentsOf: modelURL)
        else
        {
            print("unable to create model \(modelURL)")
            return nil
        }
        
        self.model = model
        
        coordinator = NSPersistentStoreCoordinator(managedObjectModel: model)
        
        persistingContext = NSManagedObjectContext(concurrencyType: .privateQueueConcurrencyType)
        persistingContext.persistentStoreCoordinator = coordinator
        
        context = NSManagedObjectContext(concurrencyType: .mainQueueConcurrencyType)
        context.parent = persistingContext
        
        backgroundContext = NSManagedObjectContext(concurrencyType: .privateQueueConcurrencyType)
        backgroundContext.parent = context
        
        let fileManager = FileManager.default
        
        guard let documentUrl = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first
        else
        {
            print("unable to reach the document folder")
            return nil
        }
        
        self.dbURL = documentUrl.appendingPathComponent("model.sqlite")
        
        let option = [NSInferMappingModelAutomaticallyOption: true,
                      NSMigratePersistentStoresAutomaticallyOption: true
                     ]
        do
        {
            try addStoreCoordinator(NSSQLiteStoreType, configuration: nil, storeURL: dbURL, option: option as [NSObject : AnyObject]?)
        }
        catch
        {
            print("unable to add store at \(dbURL)")
        }
    }
    
    func addStoreCoordinator(_ storeType: String, configuration: String?, storeURL: URL, option: [NSObject:AnyObject]? ) throws
    {
        try coordinator.addPersistentStore(ofType: NSSQLiteStoreType, configurationName: nil, at: dbURL, options: nil)
    }
    
    func fetchingPin(_ predicate: NSPredicate, entityName: String, sorting: NSSortDescriptor? = nil) throws -> Pin?
    {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: entityName)
        fetchRequest.predicate = predicate
        if let sorting = sorting
        {
            fetchRequest.sortDescriptors = [sorting]
        }
        
        guard let pin = try (context.fetch(fetchRequest) as! [Pin]).first
        else
        {
            return nil
        }
        return pin
    }
    
    func fetchingAllPins(_ predicate: NSPredicate? = nil, entityName: String, sorting: NSSortDescriptor? = nil) throws -> [Pin]?
    {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: entityName)
        fetchRequest.predicate = predicate
        if let sorting = sorting
        {
            fetchRequest.sortDescriptors = [sorting]
        }
        
        guard let pin = try context.fetch(fetchRequest) as? [Pin]
        else
        {
            return nil
        }
        return pin
    }
    
    func fetchingPhotos(_ predicate: NSPredicate? = nil, entityName: String, sorting: NSSortDescriptor? = nil) throws -> [Photo]?
    {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: entityName)
        fetchRequest.predicate = predicate
        if let sorting = sorting
        {
            fetchRequest.sortDescriptors = [sorting]
        }
        guard let photos = try context.fetch(fetchRequest) as? [Photo]
        else
        {
            return nil
        }
        return photos
    }
}

internal extension Core_Data
{
    //delete all data from tables
    func dropingAllData() throws
    {
        try coordinator.destroyPersistentStore(at: dbURL, ofType: NSSQLiteStoreType, options: nil)
        try addStoreCoordinator(NSSQLiteStoreType, configuration: nil, storeURL: dbURL, option: nil)
    }
}

extension Core_Data
{
    func saveContext() throws
    {
        context.performAndWait()
            {
                if self.context.hasChanges
                {
                    do
                    {
                        try self.context.save()
                    }
                    catch
                    {
                        print("Error while saving main context \(error)")
                    }
                    
                    self.persistingContext.perform()
                    {
                        do
                        {
                            try self.persistingContext.save()
                        }
                        catch
                        {
                            print("Error while saving persisting context \(error)")
                        }
                    }
                }
        }
    }
    
    func autoSaving(_ delayInSeconds: Int)
    {
        if delayInSeconds > 0
        {
            do
            {
                try saveContext()
                print("AutoSaving")
            }
            catch
            {
                print("Error while autoSaving")
            }
            
            let delayInNanoSeconds = UInt64(delayInSeconds) * NSEC_PER_SEC
            let time = DispatchTime.now() + Double(Int64(delayInNanoSeconds)) / Double(NSEC_PER_SEC)
            DispatchQueue.main.asyncAfter(deadline: time)
            {
                self.autoSaving(delayInSeconds)
            }
        }
    }
}

