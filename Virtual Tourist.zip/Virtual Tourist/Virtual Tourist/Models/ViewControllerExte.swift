//
//  ViewControllerExte.swift
//  Virtual Tourist
//
//  Created by Fadhel Alanazi on 03/04/1441 AH.
//  Copyright © 1441 udacity.com. All rights reserved.
//

import Foundation
import UIKit

extension UIViewController
{
    var appDelegate: AppDelegate
    {
        return UIApplication.shared.delegate as! AppDelegate
    }
    
    func save()
    {
        do
        {
            try Core_Data.shared().saveContext()
        }
        catch
        {
            showAlert(title: "Error", message: "Error while saving location \(error)")
        }
    }
    
    func showAlert(title: String = "Alert", message: String, action: (() -> Void)? = nil)
    {
        performUIUpdatesOnMin
        {
            let ac = UIAlertController(title: title, message: message, preferredStyle: .alert)
            ac.addAction(UIAlertAction(title: "OK", style: .default, handler: { (alertAction) in
                action?()
            }))
            self.present(ac, animated: true)
        }
    }
    
    func performUIUpdatesOnMin(_ updates: @escaping () -> Void)
    {
        DispatchQueue.main.async
        {
            updates()
        }
    }
}
