//
//  PhotoCoreData.swift
//  Virtual Tourist
//
//  Created by Fadhel Alanazi on 02/04/1441 AH.
//  Copyright © 1441 udacity.com. All rights reserved.
//

import Foundation
import CoreData

@objc(Photo)
public class Photo: NSManagedObject
{
    static let name = "Photo"
    
    convenience init(title: String, imageUrl: String, forPin: Pin, context: NSManagedObjectContext)
    {
        if let entity = NSEntityDescription.entity(forEntityName: Photo.name, in: context)
        {
            self.init(entity: entity, insertInto: context)
            self.title = title
            self.image = nil
            self.imageUrl = imageUrl
        }
        else
        {
            fatalError("No entity with name Pin")
        }
      }
}

extension Photo
{
    @nonobjc public class func fetchRequest() -> NSFetchRequest<Photo>
    {
        return NSFetchRequest<Photo>(entityName: "Photo")
    }
    
    @NSManaged public var image: NSData?
    @NSManaged public var title: String?
    @NSManaged public var imageUrl: String?
    @NSManaged public var pin: Pin?
}
