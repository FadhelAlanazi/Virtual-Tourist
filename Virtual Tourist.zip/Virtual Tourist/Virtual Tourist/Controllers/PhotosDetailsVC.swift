//
//  PhotosDetailsVC.swift
//  Virtual Tourist
//
//  Created by Fadhel Alanazi on 03/04/1441 AH.
//  Copyright © 1441 udacity.com. All rights reserved.
//

import UIKit
import MapKit
import CoreData

class PhotosDetailsVC: UIViewController, MKMapViewDelegate
{
    var pin: Pin?
    var photos: [Photo]!
    var presintingAlert = false
    var fetchedResultsController: NSFetchedResultsController<Photo>!
    
    var selectedIndex = [IndexPath]()
    var insertedIndexPaths: [IndexPath]!
    var deletedIndexPaths: [IndexPath]!
    var updatedIndexPaths: [IndexPath]!
    var totalPages: Int? = nil
    
    
    @IBOutlet weak var mapDetailView: MKMapView!
    @IBOutlet weak var collectionDetailsPhotos: UICollectionView!
    @IBOutlet weak var activityInd: UIActivityIndicatorView!
    @IBOutlet weak var newCollectionButton: UIButton!
    @IBOutlet weak var labelDetails: UILabel!
    @IBOutlet weak var FlowlayoutColl: UICollectionViewFlowLayout!

    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        updateFlowLayoutColl(view.frame.size)
        mapDetailView.delegate = self
        mapDetailView.isZoomEnabled = true
        mapDetailView.isScrollEnabled = true
        
        updatelabelDetails("")
        
        guard let pin = pin
        else
        {
            return
        }
        showOnMap(pin)
        setUpFetchingResultController(pin)
        
        if let photos = pin.photos, photos.count == 0
        {
            fetchingPhotosFromAPI(pin)
        }
    }
    
    private func updatelabelDetails(_ text: String)
    {
        self.performUIUpdatesOnMin
        {
            self.labelDetails.text = text
        }
        
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator)
    {
        updateFlowLayoutColl(size)
    }
    
    @IBAction func deleteCollPhotos(_ sender: Any)
    {
        for photos in fetchedResultsController.fetchedObjects!
        {
            Core_Data.shared().context.delete(photos)
        }
        save()
        fetchingPhotosFromAPI(pin!)
    }
    
    private func setUpFetchingResultController(_ pin: Pin)
    {
        let fetchRequest = NSFetchRequest<Photo>(entityName: Photo.name)
        fetchRequest.sortDescriptors = []
        fetchRequest.predicate = NSPredicate(format: "pin == %@", argumentArray: [pin])
        
        fetchedResultsController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: Core_Data.shared().context, sectionNameKeyPath: nil, cacheName: nil)
        fetchedResultsController.delegate = self
        
        var error: NSError?
        do
        {
            try fetchedResultsController.performFetch()
        }
        catch let errors as NSError
        {
            error = errors
        }
        
        if let error = error
        {
            print("error performing fetch \(error)")
        }
    }
    
    private func fetchingPhotosFromAPI(_ pin: Pin)
    {
        let latitude = Double(pin.latitude!)!
        let longitude = Double(pin.longitude!)!
        
        activityInd.startAnimating()
        self.updatelabelDetails("Fetching photos")
        
        ClientRequest.shared().searchingBy(latitude: latitude, longitue: longitude, totalPages: totalPages) { (photosParsed, error) in
            
            self.performUIUpdatesOnMin
            {
                self.activityInd.stopAnimating()
                self.labelDetails.text = ""
            }
            
            if let photosParsed = photosParsed
            {
                self.totalPages = photosParsed.photos.pages
                let totalPhotos = photosParsed.photos.photo.count
                print("Downloading \(totalPhotos) photos")
                self.storePhotos(photosParsed.photos.photo, forPin: pin)
                if totalPhotos == 0
                {
                    self.updatelabelDetails("No photos found for this location")
                }
            }
            else if let error = error
            {
                print("error \(error)")
                self.showAlert(title: "Error", message: error.localizedDescription)
                self.updatelabelDetails("Something went wrong please try again")
            }
        }
    }
    
    private func storePhotos(_ photos: [PhotoParse], forPin: Pin)
    {
        func showMessage(message: String)
        {
            showAlert(title: "Error", message: message)
        }
        
        for photo in photos
        {
            performUIUpdatesOnMin
            {
                if let url = photo.url
                {
                    _ = Photo(title: photo.title, imageUrl: url, forPin: forPin, context: Core_Data.shared().context)
                    self.save()
                }
            }
        }
    }
    
    private func showOnMap(_ pin: Pin)
    {
        let latitude = Double(pin.latitude!)!
        let longitude = Double(pin.longitude!)!
        let locationCoordinate = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
        
        let annotation = MKPointAnnotation()
        annotation.coordinate = locationCoordinate
        
        mapDetailView.removeAnnotations(mapDetailView.annotations)
        mapDetailView.addAnnotation(annotation)
        mapDetailView.setCenter(locationCoordinate, animated: true)
    }
    
    private func loadingPhotos(using pin: Pin) -> [Photo]?
    {
        let predicate = NSPredicate(format: "pin == %@", argumentArray: [pin])
        var photos: [Photo]?
        do
        {
            try photos = Core_Data.shared().fetchingPhotos(predicate, entityName: Photo.name)
        }
        catch
        {
            print("Error \(error)")
            showAlert(title: "error", message: "Error while loading Photos \(error)")
        }
        return photos
    }
    
    private func updateFlowLayoutColl(_ size: CGSize)
    {
        let landscape = size.width > size.height
        
        let space: CGFloat = landscape ? 5 : 3
        let items: CGFloat = landscape ? 2 : 3
        
        let dimension = (size.width - ((items + 1) * space)) / items
        
        FlowlayoutColl.minimumInteritemSpacing = space
        FlowlayoutColl.minimumLineSpacing = space
        FlowlayoutColl.itemSize = CGSize(width: dimension, height: dimension)
        FlowlayoutColl.sectionInset = UIEdgeInsets(top: space, left: space, bottom: space, right: space)
    }
    
    func updateBottomButton()
    {
        if selectedIndex.count > 0
        {
            newCollectionButton.setTitle("Remove Selected", for: .normal)
        }
        else
        {
            newCollectionButton.setTitle("New Collection", for: .normal)
        }
    }
}

 //MapView

extension PhotosDetailsVC
{
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView?
    {
        
        let reuseId = "pin"
        
        var pinView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId) as? MKPinAnnotationView
        
        if pinView == nil
        {
            pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
            pinView!.canShowCallout = false
            pinView!.pinColor = .red
            pinView!.animatesDrop = true
        }
        else
        {
            pinView!.annotation = annotation
        }
        
        return pinView
    }
}


 // Collection

extension PhotosDetailsVC: UICollectionViewDelegate, UICollectionViewDataSource
{
    
    func numberOfSections(in collectionView: UICollectionView) -> Int
    {
        return fetchedResultsController.sections?.count ?? 0
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        
        if let sectionDetails = self.fetchedResultsController.sections?[section]
        {
            print(collectionView)
            return sectionDetails.numberOfObjects
            
        }
        return 0
        
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PhotosCollectionCells", for: indexPath) as! PhotosCollectionCells
        cell.imageCell.image = nil
        cell.activity.startAnimating()
        return cell
    }
    
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath)
    {
        let photo = fetchedResultsController.object(at: indexPath)
        let photoViewCell = cell as! PhotosCollectionCells
        photoViewCell.imageUrl = photo.imageUrl!
        
        configureImage(using: photoViewCell, photo: photo, collectionView: collectionView, index: indexPath)
    }
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        let photoDelete = fetchedResultsController.object(at: indexPath)
        Core_Data.shared().context.delete(photoDelete)
        save()
    }
    
    
    func collectionView(_ collectionView: UICollectionView, didEndDisplaying cell: UICollectionViewCell, forItemAt indexPath: IndexPath)
    {
        if collectionView.cellForItem(at: indexPath) == nil
        {
            return
        }
        
        let photo = fetchedResultsController.object(at: indexPath)
        if let imageUrl = photo.imageUrl
        {
            ClientRequest.shared().cancelDownload(imageUrl)
        }
    }
    
    
    private func configureImage(using cell: PhotosCollectionCells, photo: Photo, collectionView: UICollectionView, index: IndexPath)
    {
        if let imageData = photo.image
        {
            cell.activity.stopAnimating()
            cell.imageCell.image = UIImage(data: Data(referencing: imageData))
        }
        else
        {
            if let imageUrl = photo.imageUrl
            {
                cell.activity.startAnimating()
                ClientRequest.shared().downloadImage(imageUrl: imageUrl) { (data, error) in
                    
                    if let _ = error
                    {
                        self.performUIUpdatesOnMin
                            {
                                cell.activity.stopAnimating()
                                self.errorImageDownload(imageUrl)
                        }
                        return
                    }
                        
                    else if let data = data
                    {
                        self.performUIUpdatesOnMin
                            {
                                if let currentCell = collectionView.cellForItem(at: index) as? PhotosCollectionCells
                                {
                                    if currentCell.imageUrl == imageUrl
                                    {
                                        currentCell.imageCell.image = UIImage(data: data)
                                        cell.activity.stopAnimating()
                                    }
                                }
                                photo.image = NSData(data: data)
                                DispatchQueue.global(qos: .background).async
                                    {
                                        self.save()
                                }
                        }
                    }
                }
            }
        }
    }
    
    private func errorImageDownload(_ imageUrl: String)
    {
        if !self.presintingAlert
        {
            self.showAlert(title: "Error", message: "Error while fetching image", action:{
                self.presintingAlert = false
            })
        }
        self.presintingAlert = true
    }
    
}


// Fetching

extension PhotosDetailsVC: NSFetchedResultsControllerDelegate
{
    func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        insertedIndexPaths = [IndexPath]()
        deletedIndexPaths = [IndexPath]()
        updatedIndexPaths = [IndexPath]()
    }
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?)
    {
        switch (type)
        {
        case .insert:
            insertedIndexPaths.append(newIndexPath!)
            break
        case .delete:
            deletedIndexPaths.append(indexPath!)
            break
        case .update:
            updatedIndexPaths.append(indexPath!)
            break
        case .move:
            print("Moving item")
            break
        }
    }
    
    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>)
    {
        collectionDetailsPhotos.performBatchUpdates({
            for index in self.insertedIndexPaths
            {
                self.collectionDetailsPhotos.insertItems(at: [index])
            }
            
            for index in self.deletedIndexPaths
            {
                self.collectionDetailsPhotos.deleteItems(at: [index])
            }
            
            for index in self.updatedIndexPaths
            {
                self.collectionDetailsPhotos.reloadItems(at: [index])
            }
            
        }, completion: nil)
    }
}
