//
//  ViewController.swift
//  Virtual Tourist
//
//  Created by Fadhel Alanazi on 02/04/1441 AH.
//  Copyright © 1441 udacity.com. All rights reserved.
//

import UIKit
import MapKit

class TravelVC: UIViewController, MKMapViewDelegate
{

    @IBOutlet weak var mapView: MKMapView!
    var pinAnnotation: MKPointAnnotation? = nil
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        mapView.delegate = self
        
        if let pins = loadAllPins()
        {
            showPins(pins)
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if segue.destination is PhotosDetailsVC
        {
            guard let pin = sender as? Pin
            else
            {
                return
            }
            let controller = segue.destination as! PhotosDetailsVC
            controller.pin = pin
        }
    }

   
    @IBAction func longPressGestureRecognizer(_ sender: UILongPressGestureRecognizer)
    {
        let location = sender.location(in: mapView)
        let locationCoordinator = mapView.convert(location, toCoordinateFrom: mapView)
        
        if sender.state == .began
        {
            pinAnnotation = MKPointAnnotation()
            pinAnnotation!.coordinate = locationCoordinator
            print("\(locationCoordinator.latitude), \(locationCoordinator.longitude)")
            
            self.mapView.addAnnotation(pinAnnotation!)
        }
        else if sender.state == .changed
        {
            pinAnnotation!.coordinate = locationCoordinator
        }
        else if sender.state == .ended
        {
            _ = Pin(latitude: String(pinAnnotation!.coordinate.latitude), longitude: String(pinAnnotation!.coordinate.longitude), context: Core_Data.shared().context)
        }
        save()
    }
    
    
    private func loadAllPins() -> [Pin]?
    {
        var pins: [Pin]?
        do
        {
            try pins = Core_Data.shared().fetchingAllPins(entityName: Pin.name)
        }
        catch
        {
            showAlert(title: "Error", message: "Error while fetching pin \(error)")
        }
        return pins
    }
    
    private func loadPin(latitude: String, longitude: String) -> Pin?
    {
        let predicate = NSPredicate(format: "latitude == %@ AND longitude == %@", latitude, longitude)
        var pin: Pin?
        do
        {
            try pin = Core_Data.shared().fetchingPin(predicate, entityName: Pin.name)
        }
        catch
        {
            showAlert(title: "Error", message: "Error while fetching location \(error)")
        }
        return pin
    }
    
    func showPins(_ pins: [Pin])
    {
        for pin in pins where pin.latitude != nil && pin.longitude != nil
        {
            let annotation = MKPointAnnotation()
            let latitude = Double(pin.latitude!)!
            let longitude = Double(pin.longitude!)!
            annotation.coordinate = CLLocationCoordinate2DMake(latitude, longitude)
            mapView.addAnnotation(annotation)
        }
        mapView.showAnnotations(mapView.annotations, animated: true)
    }
}

extension TravelVC
{
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView?
    {
        
        let reuseId = "pin"
        
        var pinView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId) as? MKPinAnnotationView
        
        if pinView == nil
        {
            pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
            pinView!.canShowCallout = false
            pinView!.pinColor = .red
            pinView!.animatesDrop = true
        }
        else
        {
            pinView!.annotation = annotation
        }
        
        return pinView
    }
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView,calloutAccessoryControlTapped control: UIControl)
    {
        if control == view.rightCalloutAccessoryView
        {
            print("Error")
        }
    }
    
    
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView)
    {
        guard let annotation = view.annotation
            else
        {
            return
        }
        
        mapView.deselectAnnotation(annotation, animated: true)
        print("\(annotation.coordinate.latitude)\(annotation.coordinate.longitude)")
        let latitude = String(annotation.coordinate.latitude)
        let longitude = String(annotation.coordinate.longitude)
        if let pin = loadPin(latitude: latitude, longitude: longitude)
        {
            performSegue(withIdentifier: "ShowPhotosDetails", sender: pin)
        }
    }

}



