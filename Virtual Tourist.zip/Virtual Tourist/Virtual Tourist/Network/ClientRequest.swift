//
//  Client.swift
//  Virtual Tourist
//
//  Created by Fadhel Alanazi on 03/04/1441 AH.
//  Copyright © 1441 udacity.com. All rights reserved.
//

import Foundation
import UIKit

class ClientRequest
{
    var session = URLSession.shared
    private var tasks: [String: URLSessionDataTask] = [:]
    
    class func shared() -> ClientRequest
    {
        struct Singleton
        {
            static var shared = ClientRequest()
        }
        return Singleton.shared
    }
    
    func searchingBy(latitude: Double , longitue: Double, totalPages: Int?, completion: @escaping (_ result: PhotosParse?, _ error: Error?) -> Void)
    {
        var page: Int
        {
            if let totalPages = totalPages
            {
                let page = min(totalPages, 4000/FlickrParametersValues.PhotosPerPage)
                return Int(arc4random_uniform(UInt32(page)) + 1)
            }
            return 1
        }
        let bbox = bboxString(latitude: latitude, longitude: longitue)
        
        let paramters = [FlickrParametersKeys.Method: FlickrParametersValues.SearchMethod,
                         FlickrParametersKeys.APIKey: FlickrParametersValues.APIKey,
                         FlickrParametersKeys.Format: FlickrParametersValues.ResponseFormat,
                         FlickrParametersKeys.Extras: FlickrParametersValues.MediumURL,
                         FlickrParametersKeys.NoJSONCallback: FlickrParametersValues.DisableJSONCallback,
                         FlickrParametersKeys.SafeSearch: FlickrParametersValues.UseSafeSearch,
                         FlickrParametersKeys.BoundingBox: bbox,
                         FlickrParametersKeys.PhotosPerPage: "\(FlickrParametersValues.PhotosPerPage)",
                         FlickrParametersKeys.Page: "\(page)"
                        ]
        
        _ = taskGetMethod(parameters: paramters) { (data, error) in
            if let error = error
            {
                completion(nil, error)
                return
            }
            guard let data = data
            else
            {
                let userInfo = [NSLocalizedDescriptionKey: "Couldn't retrieve data"]
                completion(nil, NSError(domain: "taskGetMethod", code: 1, userInfo: userInfo))
                return
            }
            
            do
            {
                let photoParser = try JSONDecoder().decode(PhotosParse.self, from: data)
                completion(photoParser,nil)
            }
            catch
            {
                print(error)
                completion(nil, error)
            }
        }
    }
    
    func downloadImage(imageUrl: String, result: @escaping(_ result: Data?, _ error: NSError?) -> Void)
    {
        guard let url = URL(string: imageUrl)
        else
        {
            return
        }
        
        let task = taskGetMethod(nil, url, parameters: [:]) { (data, error) in
            
            result(data, error)
            self.tasks.removeValue(forKey: imageUrl)
        }
        if tasks[imageUrl] == nil
        {
            tasks[imageUrl] = task
        }
    }
    
    
    func cancelDownload(_ imageUrl: String)
    {
        tasks[imageUrl]?.cancel()
        if tasks.removeValue(forKey: imageUrl) != nil
        {
            print("task canceled \(imageUrl)")
        }
    }
}

extension ClientRequest
{
    func taskGetMethod(_ method: String? = nil,
                       _ customUrl : URL? = nil,
                       parameters: [String: String],
                       completionHandlerGet: @escaping (_ result: Data?, _ error: NSError?) -> Void)
                       -> URLSessionDataTask
    {
        let request: NSMutableURLRequest!
        if let customUrl = customUrl
        {
            request = NSMutableURLRequest(url: customUrl)
        }
        else
        {
            request = NSMutableURLRequest(url: buildURLParameters(parameters, withPathExtension: method))
        }
        
        activityIndicator(true)
        
        let task = session.dataTask(with: request as URLRequest) { (data, response, error) in
            
            func showError(_ error: String)
            {
                self.activityIndicator(false)
                print(error)
                let userInfo = [NSLocalizedDescriptionKey: error]
                completionHandlerGet(nil, NSError(domain: "taskGetMethod", code: 1, userInfo: userInfo))
            }
            
            if let error = error
            {
                if(error as NSError).code == URLError.cancelled.rawValue
                {
                    completionHandlerGet(nil, nil)
                }
                else
                {
                    showError("There was an error with your request \(error.localizedDescription)")
                }
                return
            }
            
            guard let statusCode = (response as? HTTPURLResponse)?.statusCode, statusCode >= 200 && statusCode <= 299
            else
            {
                showError("Your request returned with status code less than 200 Or more than 299")
                return
            }
            
            guard let data = data
            else
            {
                showError("No data returned with the request")
                return
            }
            
            self.activityIndicator(false)
            completionHandlerGet(data, nil)
        }
        task.resume()
        return task
    }
    
    private func buildURLParameters(_ parameters: [String: String], withPathExtension: String? = nil) -> URL
    {
        var components = URLComponents()
        components.scheme = Flickr.APIScheme
        components.host = Flickr.APIHost
        components.path = Flickr.APIPath + (withPathExtension ?? "")
        components.queryItems = [URLQueryItem]()
        
        for (key, value) in parameters
        {
            let queryItem = URLQueryItem(name: key, value: value)
            components.queryItems!.append(queryItem)
        }
        return components.url!
    }
    
    private func bboxString(latitude: Double, longitude: Double) -> String
    {
        let minimumLon = max(longitude - Flickr.SearchBBoxHalfWidth, Flickr.SearchLonRange.0)
        let minimumLat = max(latitude - Flickr.SearchBBoxHalfHeight, Flickr.SearchLatRange.0)
        
        let maximumLon = min(longitude + Flickr.SearchBBoxHalfWidth, Flickr.SearchLatRange.1)
        let maximumLat = min(latitude + Flickr.SearchBBoxHalfHeight, Flickr.SearchLatRange.1)
        return "\(minimumLon), \(minimumLat), \(maximumLon), \(maximumLat)"
    }
    
    private func activityIndicator(_ show: Bool)
    {
        DispatchQueue.main.async {
            UIApplication.shared.isNetworkActivityIndicatorVisible = show
        }
    }
}
