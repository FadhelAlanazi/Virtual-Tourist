//
//  FlickrAPI.swift
//  Virtual Tourist
//
//  Created by Fadhel Alanazi on 03/04/1441 AH.
//  Copyright © 1441 udacity.com. All rights reserved.
//
/*
Virtual Tourist

Key:
a254232c19730c6dce37f84199ae9500

Secret:
a82d7168bb1fa113
 
 */

 import Foundation
 
 extension ClientRequest
 {
 struct Flickr
 {
 static let APIScheme = "https"
 static let APIHost = "api.flickr.com"
 static let APIPath = "/services/rest"
 
 static let SearchBBoxHalfWidth = 0.2
 static let SearchBBoxHalfHeight = 0.2
 static let SearchLatRange = (-90.0, 90.0)
 static let SearchLonRange = (-180.0, 180.0)
 }
 
 struct FlickrParametersKeys
 {
 static let Method = "method"
 static let APIKey = "api_key"
 static let GalleryID = "gallery_id"
 static let Extras = "extras"
 static let Format = "format"
 static let NoJSONCallback = "nojsoncallback"
 static let SafeSearch = "safe_search"
 static let BoundingBox = "bbox"
 static let PhotosPerPage = "per_page"
 static let Accuracy = "accuracy"
 static let Page = "page"
 }
 
 struct FlickrParametersValues
 {
 static let SearchMethod = "flickr.photos.search"
 static let APIKey = "a254232c19730c6dce37f84199ae9500"
 static let ResponseFormat = "json"
 static let DisableJSONCallback = "1"
 static let MediumURL = "url_n"
 static let UseSafeSearch = "1"
 static let PhotosPerPage = 25
 static let AccuracyCityLevel = "11"
 static let AccuracyStreetLevel = "16"
 }
 
 }

